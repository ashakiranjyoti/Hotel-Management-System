package hotel.management.system;

import java.sql.*;
import java.awt.*;
import java.awt.event.*;

public class Conn {
    
    Connection c;
    Statement s;
    
    Conn() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotelmanagementsystem", "root", "TIGER");
            s = c.createStatement();
            
        } catch(Exception e) {
            e.printStackTrace();
        }
        
    }
}
